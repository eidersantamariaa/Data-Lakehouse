# ingesta.py - se ejecuta DENTRO del contenedor con spark-submit
import json
from urllib.parse import quote

import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from pyspark.sql import SparkSession
import pyspark


# 1. Inicializar Spark
conf = (
    pyspark.SparkConf()
        .setAppName('ingesta_players')
        .set('spark.jars.packages', 'org.apache.iceberg:iceberg-spark-runtime-4.0_2.13:1.10.1')
        .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
        .set("spark.sql.catalog.players", "org.apache.iceberg.spark.SparkCatalog")
        .set("spark.sql.catalog.players.type", "rest")
        .set("spark.sql.catalog.players.uri", "http://rest:8181")
        .set("spark.sql.catalog.players.warehouse", "s3a://warehouse/wh")
        .set("spark.sql.catalog.players.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
        .set("spark.sql.catalog.players.s3.endpoint", "http://minio:9000")
)
spark = SparkSession.builder.config(conf=conf).getOrCreate()

spark.sql("CREATE NAMESPACE IF NOT EXISTS players.bronze")

# 2. Recoger datos de la API (tu código actual, sin cambios)

base_url = "http://host.docker.internal:8000"
session = requests.Session()

def getBig5():
    print("Getting Big 5 Leagues...")

    all_leagues = []
    all_keys = set()
    leagues = {"Premier League": "England", "LaLiga": "Spain", "Serie A": "Italy", "Bundesliga": "Germany", "Ligue 1": "France"}
    big5 = {}

    # Función para obtener una liga
    def fetch_league(name, country):
        safe_name = quote(name)
        url = f"{base_url}/competitions/search/{safe_name}"
        res = session.get(url)
        if res.status_code != 200:
            print(f"Error {res.status_code} fetching {name}")
            return []
        data = res.json()
        results = []
        for league in data.get("results", []):
            if (league["name"], league["country"]) == (name, country):
                results.append(league)
        return results

    # Paralelizar requests de ligas
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(fetch_league, name, country): name for name, country in leagues.items()}
        for future in as_completed(futures):
            for league in future.result():
                big5[league["name"]] = league["id"]
                all_leagues.append(league)

    # Guardar Iceberg
    df = spark.createDataFrame(all_leagues)
    df.writeTo("players.bronze.leagues").createOrReplace()
    print("Big 5 Leagues written to Iceberg successfully")
    return big5

def getTeams():
    big5_leagues = getBig5()
    print("Getting Teams...")
    teams = {}

    def fetch_teams(league_name, league_id):
        url = f"{base_url}/competitions/{league_id}/clubs"
        res = session.get(url)
        if res.status_code != 200:
            print(f"Error fetching clubs for {league_name}: {res.status_code}")
            return league_name, []
        data = res.json()
        league_teams = [(team["id"], team["name"]) for team in data.get("clubs", []) if team.get("id") and team.get("name")]
        return league_name, league_teams

    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(fetch_teams, name, id): name for name, id in big5_leagues.items()}
        for future in as_completed(futures):
            league_name, league_teams = future.result()
            teams[league_name] = league_teams

    print("Teams retrieved successfully.")
    writeTeamsToIceberg(teams)
    return teams

def writeTeamsToIceberg(teamsList):
    def fetch_team_profile(team_id):
        url = f"{base_url}/clubs/{team_id}/profile"
        try:
            res = session.get(url)
            if res.status_code == 200:
                return res.json()
        except Exception as e:
            print(f"Exception fetching team {team_id}: {e}")
        return None

    print("Writing Teams to Iceberg...")
    all_teams = []
    all_team_ids = [
        team_id
        for league_teams in teamsList.values()
        for team_id, _ in league_teams
    ]

    # 👇 20 threads paralelos
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(fetch_team_profile, team_id) for team_id in all_team_ids]

        for future in as_completed(futures):
            team = future.result()
            if team:
                all_teams.append(team)

    df = spark.createDataFrame(all_teams)
    df.writeTo("players.bronze.teams").createOrReplace()

    print(f"Teams written to Iceberg successfully. Total: {len(all_teams)}")


def getPlayers():
    teams = getTeams()
    print("Getting Players...")
    players = {}

    def fetch_players(team_name, team_id):
        url = f"{base_url}/clubs/{team_id}/players"
        try:
            res = session.get(url)
            if res.status_code != 200:
                print(f"Error fetching players for {team_name}: {res.status_code}")
                return team_id, team_name, []
            data = res.json()
            team_players = [(p["id"], p["name"]) for p in data.get("players", []) if p.get("id") and p.get("name")]
            return team_id, team_name, team_players
        except Exception as e:
            print(f"Exception fetching players for {team_name}: {e}")
            return team_id, team_name, []

    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [
            executor.submit(fetch_players, team_name, team_id)
            for league in teams.values()
            for team_id, team_name in league
        ]
        for future in as_completed(futures):
            try:
                team_id, team_name, team_players = future.result()  # ✅ nunca crashea
                players[team_id] = (team_name, team_players)
            except Exception as e:
                print(f"Unhandled exception: {e}")

    print("Players retrieved successfully.")
    writePlayersToIceberg(players)
    return players

def writePlayersToIceberg(playersList):

    def fetch_player_profile(player_id):
        url = f"{base_url}/players/{player_id}/profile"
        try:
            res = session.get(url)
            if res.status_code == 200:
                return res.json()
            print(f"Error fetching player {player_id}: {res.status_code}")
        except Exception as e:
            print(f"Exception fetching player {player_id}: {e}")
        return None
    
    print("Writing Players to Iceberg...")

    all_player_ids = [
        player_id
        for team_name, team_players in playersList.values()
        for player_id, _ in team_players
    ]

    all_players = []

    print("Total player IDs:", len(all_player_ids))

    # 👇 20 threads paralelos
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = [executor.submit(fetch_player_profile, player_id) for player_id in all_player_ids]

        for future in as_completed(futures):
            try:
                player = future.result()
                if player:
                    print(player.get("name", "Unknown Player"))
                    all_players.append(player)
            except Exception as e:
                print(f"Exception in player: {e}")

    print(f"Total profiles fetched: {len(all_players)}")
    df = spark.read.json(spark.sparkContext.parallelize(
        [json.dumps(p) for p in all_players]
    ))
    df.writeTo("players.bronze.players").createOrReplace()
    print("Players written to Iceberg successfully.")

getPlayers()
