from pyspark.sql import SparkSession
from Normalizar import normalize_text_udf
from pyspark.sql.functions import col
import pyspark

def normalise_leagues(df):
    return df.withColumn("strLeague",  normalize_text_udf(col("strLeague"))) \
             .withColumn("strCountry", normalize_text_udf(col("strCountry")))

def get_spark():
    conf = (
        pyspark.SparkConf()
            .setAppName('ingesta')
            .set('spark.jars.packages', 'org.apache.iceberg:iceberg-spark-runtime-4.0_2.13:1.10.1')
            .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            .set("spark.sql.catalog.players", "org.apache.iceberg.spark.SparkCatalog")
            .set("spark.sql.catalog.players.type", "rest")
            .set("spark.sql.catalog.players.uri", "http://rest:8181")
            .set("spark.sql.catalog.players.warehouse", "s3a://warehouse/wh")
            .set("spark.sql.catalog.players.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
            .set("spark.sql.catalog.players.s3.endpoint", "http://minio:9000")
    )
    return SparkSession.builder.config(conf=conf).getOrCreate()

def run():
    spark = get_spark()
    df = spark.table("players.thesportsdb.leagues_plata")
    df_normalised = normalise_leagues(df)
    df_normalised.writeTo("players.thesportsdb.leagues_plata").createOrReplace()
    print("✅ Leagues normalised")