from pyspark.sql.functions import col, when, trim, regexp_replace, concat_ws, array_join, concat, lit
from limpieza import clean_basic, normalize_text_udf

NAMESPACE = "thesportsdb"

SILVER_TRANSFORMS = {
    "leagues": lambda df: clean_basic(df).select(
        col("idLeague"),
        normalize_text_udf(col("strLeague")).alias("strLeague"),
        normalize_text_udf(col("strCountry")).alias("country"),
        col('intFormedYear')
    ),
    "teams": lambda df: clean_basic(df).select(
        col("idTeam"),
        col("strTeam"),
        col("intFormedYear"),
        col("strStadium"),
        col("intStadiumCapacity"),
        col("strLocation"),
        col("strCountry")
    ),
    "players": lambda df: clean_basic(df).select(
        col("idPlayer"),
        col("strPlayer"),
        col("dateBorn").cast("date"),
        col("strStatus"),
        col("strHeight"),
        col("strSide"),
        col("strWeight"),
        col("strNumber"),
        col("strBirthLocation"),
        col("strNationality"),
        col("strPosition"),
        col("strSigning"),
        col("strWage")
    )
}