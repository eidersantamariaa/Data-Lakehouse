import Normalizar as norm
from pyspark.sql import SparkSession
import pyspark

def normalise_leagues(df):
    id = col("id")
    name = col("name")
    country = col("country")
    continent = col("continent")
    clubs = col("clubs")
    players = col("players")
    totalMarketValue = col("totalMarketValue")
    meanMarketValue = col("meanMarketValue")

    df["name"] = df["name"].apply(norm.normalize_text(name))
    df["country"] = df["country"].apply(norm.normalize_text(country))
    df["continent"] = df["continent"].apply(norm.normalize_text(continent))
    df["totalMarketValue"] = df["totalMarketValue"].apply(norm.normalize_currency(totalMarketValue))
    df["meanMarketValue"] = df["meanMarketValue"].apply(norm.normalize_currency(meanMarketValue))

    return df

def get_spark():
    conf = (
        pyspark.SparkConf()
            .setAppName('ingesta')
            .set('spark.jars.packages', 'org.apache.iceberg:iceberg-spark-runtime-4.0_2.13:1.10.1')
            .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            .set("spark.sql.catalog.players", "org.apache.iceberg.spark.SparkCatalog")
            .set("spark.sql.catalog.players.type", "rest")
            .set("spark.sql.catalog.players.uri", "http://rest:8181")
            .set("spark.sql.catalog.players.warehouse", "s3a://warehouse/wh")
            .set("spark.sql.catalog.players.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
            .set("spark.sql.catalog.players.s3.endpoint", "http://minio:9000")
    )
    return SparkSession.builder.config(conf=conf).getOrCreate()

spark = get_spark()
df_bronze = spark.table("players.transfermarkt.leagues_plata")
print(normalise_leagues(df_bronze))