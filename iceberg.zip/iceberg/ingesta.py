import json
from pyspark.sql import SparkSession
import pyspark

def get_spark():
    conf = (
        pyspark.SparkConf()
            .setAppName('ingesta')
            .set('spark.jars.packages', 'org.apache.iceberg:iceberg-spark-runtime-4.0_2.13:1.10.1')
            .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
            .set("spark.sql.catalog.players", "org.apache.iceberg.spark.SparkCatalog")
            .set("spark.sql.catalog.players.type", "rest")
            .set("spark.sql.catalog.players.uri", "http://rest:8181")
            .set("spark.sql.catalog.players.warehouse", "s3a://warehouse/wh")
            .set("spark.sql.catalog.players.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
            .set("spark.sql.catalog.players.s3.endpoint", "http://minio:9000")
    )
    return SparkSession.builder.config(conf=conf).getOrCreate()


def run_ingesta(config):
    spark = get_spark()
    spark.sql(f"CREATE NAMESPACE IF NOT EXISTS players.{config.NAMESPACE}")

    data = config.get_data()  # {"leagues": [...], "teams": [...], "players": [...]}

    for table_name, records in data.items():
        print(f"Writing {table_name} to Bronze... ({len(records)} records)")
        df = spark.read.json(spark.sparkContext.parallelize(
            [json.dumps(r) for r in records]
        ))
        df.writeTo(f"players.{config.NAMESPACE}.{table_name}_bronce").createOrReplace()
        print(f"✅ {table_name} written successfully")