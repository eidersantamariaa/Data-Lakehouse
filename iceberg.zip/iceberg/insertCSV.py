import pyspark
from pyspark.sql import SparkSession
import os

conf = (
    pyspark.SparkConf()
        .setAppName('app_name')
  		#packages
        .set('spark.jars.packages', 'org.apache.iceberg:iceberg-spark-runtime-4.0_2.13:1.10.1')
  		#SQL Extensions
        .set('spark.sql.extensions', 'org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions')
  		#Configuring Catalog
         # Configuración catálogo REST
         .set("spark.sql.catalog.players", "org.apache.iceberg.spark.SparkCatalog")
         .set("spark.sql.catalog.players.type", "rest")                      # RESTCatalog
         .set("spark.sql.catalog.players.uri", "http://rest:8181")           # URI del servidor REST
         .set("spark.sql.catalog.players.warehouse", "s3a://warehouse/wh")  # Ruta base en S3
         .set("spark.sql.catalog.players.io-impl", "org.apache.iceberg.aws.s3.S3FileIO")
         .set("spark.sql.catalog.players.s3.endpoint", "http://minio:9000")
         #.set('spark.sql.catalog.spark_catalog', 'org.apache.iceberg.spark.SparkSessionCatalog')
         #.set('spark.sql.catalog.spark_catalog.type', 'hive')
         #.set('spark.sql.catalog.local', 'org.apache.iceberg.spark.SparkCatalog')
         #.set('spark.sql.catalog.local.type', 'hadoop')
         #.set('spark.sql.catalog.local.warehouse', '$PWD/warehouse')
         #.set('spark.sql.defaultCatalog', 'local')
)

## Start Spark Session
spark = SparkSession.builder.config(conf=conf).getOrCreate()
print("Spark Running")

#CREAR NAMESPACE DENTRO DE CATALOG
spark.sql("CREATE NAMESPACE test")

#ESTE DOCKER PRUEBA NO ADMITE PATHS FUERA DE SU CONTENEDOR ASI QUE HAY QUE MOVER EL ARCHIVO AHÍ DESDE LA TERMINAL WINDOWS
#docker cp "C:/Users/esantamaria/Documents/proiektua/CSV/big5_teams.csv" spark-iceberg:/opt/spark/data/big5_teams.csv

# leer CSV con schema inferido
csv_df = (
    spark.read
        .format("csv")
        .option("header", "true")
        .option("sep", ";")
        .option("inferSchema", "true")
        .load("/opt/spark/data/big5_teams.csv")
)

# crear tabla Iceberg automáticamente
csv_df.writeTo("demo.test.csv").createOrReplace()

# comprobar
spark.sql("SELECT * FROM demo.test.csv LIMIT 5").show()

spark.sql("DROP TABLE IF EXISTS demo.test.csv")



