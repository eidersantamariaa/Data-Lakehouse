from pyparsing import col

import transfermarkt_bronce as transfermarkt_bronce
import transfermarkt_plata as transfermarkt_plata
import thesportsdb_bronce as sports_bronce
import thesportsdb_plata as sports_plata
from ingesta import run_ingesta
from limpieza import run_silver

#run_ingesta(transfermarkt_bronce)
#run_silver(transfermarkt_plata)

#run_ingesta(sports_bronce)
run_silver(sports_plata) 
