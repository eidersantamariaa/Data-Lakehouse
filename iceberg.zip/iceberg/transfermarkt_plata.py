from pyspark.sql.functions import col, when, trim, regexp_replace, concat_ws, array_join, concat, lit
from limpieza import clean_basic

NAMESPACE = "transfermarkt"

SILVER_TRANSFORMS = {
    "leagues": lambda df: clean_basic(df).select(
        col("id"),
        col("name"),
        col("country"),
        col("continent"),
        col("clubs"),
        col("players"),
        col("totalMarketValue"),
        col("meanMarketValue")
    ),
    "teams": lambda df: clean_basic(df).select(
        col("id"),
        col("name"),
        col("officialName"),
        col("foundedOn").cast("date").alias("foundedOn"),
        col("legalForm"),
        col("stadiumName"),
        col("stadiumSeats"),
        col("currentMarketValue"),
        col("currentTransferRecord"),
        array_join(col("colors"), ", ").alias("colors"),
        col("league")["id"].alias("leagueId"),
        col("league")["name"].alias("leagueName"),
        col("league")["countryName"].alias("leagueCountry"),
        col("league")["tier"].alias("leagueTier"),
        col("squad")["size"].alias("squadSize"),
        col("squad")["nationalTeamPlayers"].alias("squadNationalPlayers"),
        col("addressLine1"),
        col("addressLine2"),
        col("addressLine3"),
        col("tel"),
        col("website")
    ),
    "players": lambda df: clean_basic(df).select(
        col("id"),
        col("name"),
        col("fullName"),
        col("dateOfBirth").cast("date").alias("dateOfBirth"),
        col("nameInHomeCountry"),
        col("height"),
        col("foot"),
        col("shirtNumber"),
        col("outfitter"),
        col("marketValue"),
        col("isRetired"),
        array_join(col("citizenship"), ", ").alias("citizenship"),

        when(col("placeOfBirth.city").isNotNull() & col("placeOfBirth.country").isNotNull(),
            concat(col("placeOfBirth.city"), lit(", "), col("placeOfBirth.country"))
        ).when(col("placeOfBirth.country").isNull(), 
            col("placeOfBirth.city")
        ).otherwise(
            col("placeOfBirth.country")
        ).alias("placeOfBirth"),

        trim(regexp_replace(
            concat_ws(", ", col("position.main"), array_join(col("position.other"), ", ")),
            ",\\s*$", ""  # quita coma y espacios al final
        )).alias("positions"),
        
        col("club.id").alias("clubId"),
        col("club.name").alias("clubName"),
        col("club.joined").cast("date").alias("clubJoined"),
        col("club.contractExpires").cast("date").alias("contractExpires"),
        col("agent.name").alias("agentName")
    )
}

def normalise():
    pass
